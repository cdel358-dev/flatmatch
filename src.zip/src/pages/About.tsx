export default function About() {
  return (
    <section className="prose dark:prose-invert max-w-none">
      <h1>About FlatMatch</h1>
      <p>
        FlatMatch is your go-to responsive starter built on React, Tailwind, and TypeScript.
      </p>
    </section>
  );
}