export default function Saved() {
  return (
    <section className="prose dark:prose-invert max-w-none">
      <h1>Saved Listings</h1>
      <p>
        This page will list the flats the user has saved. Integrate with your backend
        or state management to display the actual saved results here.
      </p>
    </section>
  );
}
