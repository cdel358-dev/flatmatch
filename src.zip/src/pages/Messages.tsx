export default function Messages() {
  return (
    <section className="prose dark:prose-invert max-w-none">
      <h1>Messages</h1>
      <p>
        This page will show conversations between flat seekers and property owners.
        Integrate with your messaging system here.
      </p>
    </section>
  );
}
